from .definitions import vkscript

__all__ = ("vkscript",)

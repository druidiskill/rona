from enum import Enum


class KeyboardButtonColor(Enum):
    PRIMARY = "primary"
    SECONDARY = "secondary"
    NEGATIVE = "negative"
    POSITIVE = "positive"

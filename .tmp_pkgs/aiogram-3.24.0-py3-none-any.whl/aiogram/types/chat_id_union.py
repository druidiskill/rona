from __future__ import annotations

from typing import TypeAlias

ChatIdUnion: TypeAlias = int | str

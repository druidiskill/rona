from __future__ import annotations

from typing import TypeAlias

from .input_file import InputFile

InputFileUnion: TypeAlias = str | InputFile

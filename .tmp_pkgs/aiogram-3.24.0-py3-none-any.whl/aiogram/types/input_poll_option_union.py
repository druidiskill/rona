from __future__ import annotations

from typing import TypeAlias

from .input_poll_option import InputPollOption

InputPollOptionUnion: TypeAlias = InputPollOption | str

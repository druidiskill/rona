from vkbottle_types.codegen.methods.wall import *  # noqa: F403,F401

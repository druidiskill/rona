from vkbottle_types.codegen.methods.translations import *  # noqa: F403,F401

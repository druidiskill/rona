from vkbottle_types.codegen.methods.gifts import *  # noqa: F403,F401

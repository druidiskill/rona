from vkbottle_types.codegen.methods.storage import *  # noqa: F403,F401

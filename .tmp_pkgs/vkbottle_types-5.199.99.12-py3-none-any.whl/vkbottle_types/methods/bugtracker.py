from vkbottle_types.codegen.methods.bugtracker import *  # noqa: F403,F401

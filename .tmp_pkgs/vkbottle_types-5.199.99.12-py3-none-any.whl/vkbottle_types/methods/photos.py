from vkbottle_types.codegen.methods.photos import *  # noqa: F403,F401

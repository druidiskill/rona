from vkbottle_types.codegen.methods.streaming import *  # noqa: F403,F401

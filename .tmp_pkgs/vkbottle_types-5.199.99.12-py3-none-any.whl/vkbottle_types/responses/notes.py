from vkbottle_types.codegen.responses.notes import *  # noqa: F403,F401

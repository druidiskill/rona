from vkbottle_types.codegen.responses.likes import *  # noqa: F403,F401

from vkbottle_types.codegen.responses.fave import *  # noqa: F403,F401

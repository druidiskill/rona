from vkbottle_types.codegen.responses.messages import *  # noqa: F403,F401


class MessagesSendPeerIdsResponse(MessagesSendUserIdsResponse):  # noqa: F405
    pass

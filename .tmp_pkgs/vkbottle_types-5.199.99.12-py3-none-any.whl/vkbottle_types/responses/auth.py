from vkbottle_types.codegen.responses.auth import *  # noqa: F403,F401
